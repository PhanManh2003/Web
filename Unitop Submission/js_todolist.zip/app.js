// data: đọc và ghi liên tục từ localStorage dưới dạng mảng các Object

// 1. saveData() vào localStorage
const todolist = 'todolist';
const saveData = (data) => {
    localStorage.setItem(todolist, JSON.stringify(data));
}


// 2. loadData() : lấy dữ liệu từ localStorage
const loadData = () => {
    let data = JSON.parse(localStorage.getItem(todolist));
    data = data ? data : []; // tránh return data bị null khi ko có gì trong localStorage
    return data
}

// 3. addTask(): Thêm dữ liệu vừa submit vào mảng data ở localStorage
const addTaskForm = document.forms.addTaskForm;
const addTask = (new_task) => {
    let data = loadData();
    data.push(new_task);
    saveData(data); // lưu lại mảng data vào localStorage

};

// 4. renderTask(): Hiển thị danh sách công việc trên giao diện
const renderTask = () => {
    let data = loadData();
    let ulHtml = data.map((element, index) => {
        return `
    <li class="task-item" index="${index}" complete="${element.complete}">
        <span onclick="markTaskComplete(${index});">${element.task}</span>
        <div class="task-option">
            <button onclick = "editTask(${index});">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                    stroke="currentColor" class="w-6 h-6 icon">
                    <path stroke-linecap="round" stroke-linejoin="round"
                        d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L6.832 19.82a4.5 4.5 0 01-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 011.13-1.897L16.863 4.487zm0 0L19.5 7.125" />
                </svg>
            </button>
            <button onclick = "deleteTask(${index});">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                    stroke="currentColor" class="w-6 h-6 icon">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>
    </li> `
    });
    const ulElement = document.querySelector('ul.task-list');
    ulElement.innerHTML = ulHtml.join('');
    // display task-result
    const taskResult = document.querySelector('span.task-result');
    if (countCompletedTask() > 0) {
        taskResult.innerHTML = `Yeah, ${countCompletedTask()} task completed!`;
    } else {
        taskResult.innerHTML = ``;
    }

}
// Lệnh submit
addTaskForm.addEventListener('submit', (e) => {
    const index = inputTask.getAttribute('index');
    if (index) {
        let data = loadData();
        data[index].task = inputTask.value;
        saveData(data);
        // Trả lại giao diện như ban đầu sau khi edit
        inputTask.removeAttribute('index');
        const addTaskButton = document.querySelector('form.task-head button');
        addTaskButton.innerText = 'ADD TASK';

    }
    else {
        let new_task = {
            task: inputTask.value, // trỏ đến thẻ input bằng chính id của nó mà ko cần truy cập qua document
            complete: false,
        }
        addTask(new_task);
    }

    inputTask.value = '';
    renderTask();
    e.preventDefault();
});

// Hiển thị nội dung như cũ khi load lại trang
window.addEventListener('load', () => {
    renderTask();
});


// 5. markTaskComplete()
const markTaskComplete = (index) => {
    let data = loadData();
    if (data[index].complete) {
        data[index].complete = false;
    } else {
        data[index].complete = true;
    }
    saveData(data);
    renderTask();
}

// 6. deleteTask()
const deleteTask = (index) => {
    let data = loadData();
    let userConfirmed = confirm("Bạn có chắc chắn muốn xóa tệp này?");

    if (userConfirmed) {
        data.splice(index, 1);
        saveData(data);
        renderTask();
    } else {
        return false;
    }
}
// 7. editTask()
const editTask = (index) => {
    // Sửa value của input
    let data = loadData();
    inputTask.value = data[index].task;

    // Sửa nút ADD TASK
    const addTaskButton = document.querySelector('form.task-head button');
    addTaskButton.innerText = 'EDIT TASK';

    // Vấn đề bây giờ là phải phân biệt 2 form ADD TASK và form EDIT TASK khi submit ???
    // => thêm 1 điều kiện rẽ nhanh cho event submit ở ADDTASK button
    inputTask.setAttribute('index', index);
}
// 8. countCompletedTask(): đếm các phần tử data có thuộc tính complete = true
const countCompletedTask = () => {
    let data = loadData();
    let completedTasks = [];
    function isComplete(dataElement) {
        return dataElement.complete === true;  // ko dùng dấy "=" vì đấy là phép gán chứ ko phải so sánh
    }
    completedTasks = data.filter(isComplete);
    // Cách khác: let completedTasks = data.filter(dataElement => dataElement.complete);
    let count = completedTasks.length;
    return count;
}


