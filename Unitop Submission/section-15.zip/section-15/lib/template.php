<?php
function get_header(){
    require 'inc/header.php';
}

function get_footer(){
    require 'inc/footer.php';
}
?>
