<?php
echo "Thông báo";

?>