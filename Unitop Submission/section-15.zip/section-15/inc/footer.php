<div id="footer">
    footer
</div>
</div>
<script src="lib/ckeditor/ckeditor.js" type="text/javascript"></script>

</body>
</html>
