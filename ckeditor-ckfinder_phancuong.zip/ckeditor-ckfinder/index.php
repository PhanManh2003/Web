<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="style.css"> -->
    <!-- <base href="http://localhost/phpmaster/ckeditor-ckfinder/"> -->
    <script src="ckeditor/ckeditor.js"></script>
    <title>Document</title>
</head>
<body>
    <h1>Ckeditor Ckfinder</h1>
    <textarea name="ckeditor" class="ckeditor" id="" cols="30" rows="10"></textarea>
</body>
</html>
<?php
print_r(phpinfo());
?>